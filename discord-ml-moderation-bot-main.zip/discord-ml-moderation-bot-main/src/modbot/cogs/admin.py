"""Administrative / introspection commands."""

import discord
from discord import app_commands
from discord.ext import commands


class Admin(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(
        name="reset_database",
        description="Reset moderation DB (users, vectors, logs). Admin only.",
    )
    @app_commands.checks.has_permissions(administrator=True)
    async def reset_database(
        self, interaction: discord.Interaction, confirm: str
    ) -> None:
        if confirm != "RESET":
            await interaction.response.send_message(
                "Reset cancelled. To proceed, run `/reset_database confirm:RESET`.",
                ephemeral=True,
            )
            return

        summary = await self.bot.db.reset_data()
        # Keep in-memory state aligned with the now-empty database.
        self.bot.spam_index = type(self.bot.spam_index)()
        self.bot.burst_tracker = type(self.bot.burst_tracker)(
            retention_seconds=self.bot.settings.tracker_retention_seconds,
            burst_window_seconds=self.bot.settings.burst_window_seconds,
            burst_channels=self.bot.settings.burst_channels,
            repeat_count=self.bot.settings.repeat_count,
        )

        embed = discord.Embed(
            title="Database Reset Complete",
            color=discord.Color.red(),
            description=(
                "All moderation runtime data has been cleared. The bot will reseed "
                "trusted users from the target guild on next ready/restart."
            ),
        )
        embed.add_field(name="Users removed", value=str(summary["users"]))
        embed.add_field(
            name="Spam vectors removed", value=str(summary["spam_vectors"])
        )
        embed.add_field(name="Log rows removed", value=str(summary["logs"]))
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="status", description="Show moderation bot status.")
    @app_commands.checks.has_permissions(administrator=True)
    async def status(self, interaction: discord.Interaction) -> None:
        settings = self.bot.settings
        trusted_count, pending_count = await self.bot.db.get_user_status_counts()
        embed = discord.Embed(
            title="Moderation Bot Status", color=discord.Color.blurple()
        )
        embed.add_field(name="Shadow mode", value=str(settings.shadow_mode))
        embed.add_field(name="Spam signatures", value=str(len(self.bot.spam_index)))
        embed.add_field(name="Trusted users", value=str(trusted_count))
        embed.add_field(name="Pending users", value=str(pending_count))
        embed.add_field(
            name="ML model",
            value="loaded" if self.bot.embedder is not None else "disabled",
        )
        embed.add_field(
            name="Thresholds",
            value=(
                f"review \u2265 {settings.review_threshold}, "
                f"delete \u2265 {settings.delete_threshold}, "
                f"timeout \u2265 {settings.timeout_threshold}"
            ),
            inline=False,
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)


async def setup(bot) -> None:
    await bot.add_cog(Admin(bot))

"""Context-aware Discord moderation bot package."""

__version__ = "0.1.0"
